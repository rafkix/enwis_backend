from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Integer,
    String,
    ForeignKey,
    DateTime,
    Float,
    Boolean,
    UniqueConstraint,
    Text
)
from sqlalchemy.orm import (
    Mapped,
    mapped_column,
    relationship
)

from app.core.database import Base

class Exam(Base):
    __tablename__ = "exams"

    id: Mapped[int] = mapped_column(primary_key=True)

    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

    exam_type: Mapped[str] = mapped_column(
        String(50),  # mock | cefr | ielts | custom
        nullable=False
    )

    level: Mapped[Optional[str]] = mapped_column(
        String(50), default="beginner"
    )

    price: Mapped[float] = mapped_column(Float, default=0.0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)

    duration_minutes: Mapped[int] = mapped_column(Integer, default=60)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow
    )

    # relations
    purchases = relationship(
        "ExamPurchase",
        back_populates="exam",
        cascade="all, delete-orphan"
    )

    attempts = relationship(
        "ExamAttempt",
        back_populates="exam",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Exam id={self.id} title={self.title}>"


class ExamPurchase(Base):
    __tablename__ = "exam_purchases"

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        index=True
    )

    exam_id: Mapped[int] = mapped_column(
        ForeignKey("exams.id", ondelete="CASCADE"),
        index=True
    )

    allowed_attempts: Mapped[int] = mapped_column(
        Integer, default=1
    )

    used_attempts: Mapped[int] = mapped_column(
        Integer, default=0
    )

    purchased_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow
    )

    # relations
    user = relationship("User", back_populates="exam_purchases")
    exam = relationship("Exam", back_populates="purchases")

    __table_args__ = (
        UniqueConstraint("user_id", "exam_id"),
    )

    def can_attempt(self) -> bool:
        return self.used_attempts < self.allowed_attempts


class ExamAttempt(Base):
    __tablename__ = "exam_attempts"

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        index=True
    )

    exam_id: Mapped[int] = mapped_column(
        ForeignKey("exams.id", ondelete="CASCADE"),
        index=True
    )

    score: Mapped[Optional[float]] = mapped_column(Float)
    max_score: Mapped[Optional[float]] = mapped_column(Float)

    passed: Mapped[bool] = mapped_column(Boolean, default=False)

    started_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow
    )

    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    # relations
    user = relationship("User", back_populates="exam_attempts")
    exam = relationship("Exam", back_populates="attempts")

    def __repr__(self):
        return f"<ExamAttempt id={self.id} user={self.user_id} exam={self.exam_id}>"

import enum
from sqlalchemy import (
    JSON, Column, DateTime, Float, Integer, String, Text, Enum, ForeignKey, Boolean, func
)
from sqlalchemy.orm import relationship
from app.core.database import Base

# --- ENUMS ---
class ListeningQuestionType(str, enum.Enum):
    MULTIPLE_CHOICE = "MULTIPLE_CHOICE"
    GAP_FILL = "GAP_FILL"
    MATCHING = "MATCHING"
    MAP_DIAGRAM = "MAP_DIAGRAM"
    SENTENCE_COMPLETION = "SENTENCE_COMPLETION"
    SHORT_ANSWER = "SHORT_ANSWER"

# --- EXAM (LISTENING) ---
# --- EXAM (LISTENING) ---
class ListeningExam(Base):
    __tablename__ = "listening_exams"

    id = Column(String, primary_key=True, index=True) 
    title = Column(String, nullable=False)
    
    # Statuslar
    is_demo = Column(Boolean, default=False)
    is_free = Column(Boolean, default=False)
    is_mock = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    # Ma'lumotlar
    cefr_level = Column(String, default="B2")
    duration_minutes = Column(Integer, default=35)
    total_questions = Column(Integer, default=40)
    
    # --- TIKLANDI: SECTIONS USTUNI ---
    # Bu maydon "1, 2, 3, 4" yoki "Part 1-4" kabi ma'lumotni saqlaydi
    sections = Column(String, nullable=True) 

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Bog'lanishlar
    parts = relationship("ListeningPart", back_populates="exam", cascade="all, delete-orphan", lazy="selectin")
    results = relationship("ListeningResult", back_populates="exam", cascade="all, delete-orphan")

# --- LISTENING PARTS (Sections) ---

class ListeningPart(Base):
    __tablename__ = "listening_parts"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(String, ForeignKey("listening_exams.id", ondelete="CASCADE"), nullable=False)
    
    part_number = Column(Integer, nullable=False) # Part 1, Part 2...
    title = Column(String, nullable=False)
    instruction = Column(Text, nullable=False)
    task_type = Column(String, nullable=False) # Frontenddagi tip (UI uchun)
    
    # Listening maxsus maydonlari
    audio_url = Column(String, nullable=False) # audio_label o'rniga url aniqroq
    context = Column(String, nullable=True) 
    passage = Column(Text, nullable=True) # Gap fill uchun matn (agar bo'lsa)
    map_image = Column(String, nullable=True) # Map labeling uchun rasm URL

    exam = relationship("ListeningExam", back_populates="parts")
    
    # Part ichidagi savollar
    questions = relationship("ListeningQuestion", back_populates="part", cascade="all, delete-orphan", lazy="selectin")
    
    # Part darajasidagi optionlar (Masalan: Matching yoki Map uchun A, B, C variantlar ro'yxati)
    options = relationship("ListeningPartOption", back_populates="part", cascade="all, delete-orphan", lazy="selectin")

# --- QUESTIONS ---
class ListeningQuestion(Base):
    __tablename__ = "listening_questions"

    id = Column(Integer, primary_key=True, index=True)
    part_id = Column(Integer, ForeignKey("listening_parts.id", ondelete="CASCADE"), nullable=False)
    
    question_number = Column(Integer, nullable=False)
    
    # native_enum=False qilib qo'yildi (xavfsizroq)
    type = Column(Enum(ListeningQuestionType, native_enum=False), nullable=False)
    
    text = Column(Text, nullable=True) # Savol matni (ba'zi turlarda bo'lmasligi mumkin)
    correct_answer = Column(String, nullable=False)

    part = relationship("ListeningPart", back_populates="questions")
    
    # Savol darajasidagi optionlar (Faqat Multiple Choice uchun)
    options = relationship("ListeningQuestionOption", back_populates="question", cascade="all, delete-orphan", lazy="selectin")

# --- PART OPTIONS (Matching / Map Labeling) ---
# Bu yerda variantlar bitta savolga emas, butun Partga tegishli bo'ladi
class ListeningPartOption(Base):
    __tablename__ = "listening_part_options"
    
    id = Column(Integer, primary_key=True, index=True)
    part_id = Column(Integer, ForeignKey("listening_parts.id", ondelete="CASCADE"), nullable=False)
    
    value = Column(String, nullable=False) # "A", "B", "C"
    label = Column(String, nullable=False) # "Library", "Gym", "Reception"

    part = relationship("ListeningPart", back_populates="options")

# --- QUESTION OPTIONS (Multiple Choice) ---
# Bu yerda variantlar har bir savolning o'zida bo'ladi
class ListeningQuestionOption(Base):
    __tablename__ = "listening_question_options"

    id = Column(Integer, primary_key=True, index=True)
    question_id = Column(Integer, ForeignKey("listening_questions.id", ondelete="CASCADE"), nullable=False)
    
    value = Column(String, nullable=False) # "A"
    label = Column(String, nullable=False) # "Javob matni"

    question = relationship("ListeningQuestion", back_populates="options")

# --- RESULTS ---
class ListeningResult(Base):
    __tablename__ = "listening_results"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    exam_id = Column(String, ForeignKey("listening_exams.id", ondelete="CASCADE"), nullable=False)
    
    raw_score = Column(Integer, default=0)
    total_questions = Column(Integer, default=0)
    correct_answers = Column(Integer, default=0)
    
    standard_score = Column(Float, default=0.0)
    cefr_level = Column(String, nullable=True)
    percentage = Column(Float, default=0.0)
    
    user_answers = Column(JSON, nullable=False, default={})
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # User modelida 'listening_results' relationship bo'lishi kerak
    user = relationship("User", back_populates="listening_results")
    exam = relationship("ListeningExam", back_populates="results")
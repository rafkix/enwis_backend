from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Any

from app.core.database import get_db
from app.modules.auth.dependencies import get_current_user

# Servis va Sxemalar importi
from .services import ListeningService
from .schemas import (
    ListeningExamResponse, 
    ListeningExamCreate, 
    ListeningExamUpdate,
    ListeningResultResponse,
    ListeningSubmission,
    ListeningResultDetailResponse # Review uchun muhim
)

router = APIRouter(
    prefix="/services/cefr/listening", 
    tags=["CEFR Listening"]
)

# --- YORDAMCHI: ADMIN TEKSHIRUVI ---
def check_admin_access(user):
    """Foydalanuvchi Admin ekanligini tekshiradi"""
    # User modelida 'role' maydoni bo'lishi kerak.
    if getattr(user, "role", "student") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, 
            detail="Bu amalni bajarish uchun Admin huquqi kerak."
        )

# =================================================================
#  ADMIN QISMI (CREATE, UPDATE, DELETE)
# =================================================================

@router.post("/create", response_model=ListeningExamResponse, status_code=status.HTTP_201_CREATED)
async def create_exam(
    data: ListeningExamCreate, 
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user)
):
    """Yangi Listening imtihoni yaratish (Faqat Admin)"""
    check_admin_access(user)
    
    service = ListeningService(db)
    # ID band emasligini tekshirish (ixtiyoriy, chunki service da ham try/except bor)
    return await service.create_exam(data)

@router.put("/update/{exam_id}", response_model=ListeningExamResponse)
async def update_exam(
    exam_id: str, 
    data: ListeningExamUpdate, # Update sxemasini ishlatish kerak
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user)
):
    """Imtihonni yangilash (Faqat Admin)"""
    check_admin_access(user)
    
    service = ListeningService(db)
    return await service.update_exam(exam_id, data)

@router.delete("/delete/{exam_id}", status_code=status.HTTP_200_OK)
async def delete_exam(
    exam_id: str, 
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user)
):
    """Imtihonni o'chirish (Faqat Admin)"""
    check_admin_access(user)
    
    service = ListeningService(db)
    return await service.delete_exam(exam_id)

# =================================================================
#  PUBLIC & USER QISMI (LIST, GET, SUBMIT)
# =================================================================

@router.get("/list", response_model=List[ListeningExamResponse])
async def get_all_exams(db: AsyncSession = Depends(get_db)):
    """Barcha imtihonlar ro'yxati (Hamma uchun ochiq)"""
    service = ListeningService(db)
    return await service.get_all_exams()

@router.get("/{exam_id}", response_model=ListeningExamResponse)
async def get_exam_by_id(exam_id: str, db: AsyncSession = Depends(get_db)):
    """Imtihon detallari va savollari (Boshlash uchun)"""
    service = ListeningService(db)
    return await service.get_exam_by_id(exam_id)

@router.post("/submit", response_model=ListeningResultDetailResponse)
async def submit_exam(
    submission: ListeningSubmission, 
    db: AsyncSession = Depends(get_db),
    current_user: Any = Depends(get_current_user)
):
    """Javoblarni yuborish va natijani olish"""
    service = ListeningService(db)
    return await service.submit_exam_and_get_result(
        user_id=current_user.id, 
        exam_id=submission.exam_id, 
        user_answers=submission.user_answers
    )
    
@router.get("/results/my", response_model=List[ListeningResultResponse])
async def get_my_results(
    db: AsyncSession = Depends(get_db),
    current_user: Any = Depends(get_current_user)
):
    """Foydalanuvchining barcha Listening natijalari"""
    service = ListeningService(db)
    return await service.get_user_results(current_user.id)

@router.get("/results/{result_id}", response_model=ListeningResultDetailResponse)
async def get_result_detail(
    result_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: Any = Depends(get_current_user)
):
    """Natija tahlili (Review)"""
    service = ListeningService(db)
    result = await service.get_result_details(result_id, current_user.id)
    
    if not result:
        raise HTTPException(status_code=404, detail="Natija topilmadi")
        
    return result
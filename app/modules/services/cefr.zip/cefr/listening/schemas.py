from pydantic import BaseModel, Field, ConfigDict
from typing import Dict, List, Optional
from datetime import datetime
from .models import ListeningQuestionType

# ================================================================
#  OPTIONS (Variantlar)
# ================================================================
class OptionBase(BaseModel):
    value: str
    label: str

class OptionCreate(OptionBase):
    pass

class OptionResponse(OptionBase):
    id: int
    model_config = ConfigDict(from_attributes=True)

# ================================================================
#  QUESTIONS (Savollar)
# ================================================================
class ListeningQuestionBase(BaseModel):
    question_number: int = Field(..., alias="questionNumber")
    type: ListeningQuestionType
    
    # MUHIM: Modelda "text", Frontendda "question".
    # Pydantic bu yerdagi 'text' maydonini JSON dagi 'question' kalitiga bog'laydi.
    text: Optional[str] = Field(None, alias="question") 
    
    model_config = ConfigDict(populate_by_name=True)

class ListeningQuestionCreate(ListeningQuestionBase):
    correct_answer: str = Field(..., alias="correctAnswer") # Yaratishda kerak
    options: Optional[List[OptionCreate]] = []

class ListeningQuestionResponse(ListeningQuestionBase):
    id: int
    options: List[OptionResponse] = []

    # XAVFSIZLIK: correct_answer bu yerda yo'q! 
    # Talaba imtihon paytida javobni "Inspect Element" qilib ko'ra olmaydi.

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

# ================================================================
#  PARTS (Sections/Parts)
# ================================================================
class ListeningPartBase(BaseModel):
    part_number: int = Field(..., alias="partNumber")
    title: str
    instruction: str
    task_type: str = Field(..., alias="taskType")
    
    # Modelda "audio_url", Frontendda "audioLabel"
    audio_url: str = Field(..., alias="audioLabel") 
    
    context: Optional[str] = None
    passage: Optional[str] = None
    map_image: Optional[str] = Field(None, alias="mapImage")

    model_config = ConfigDict(populate_by_name=True)

class ListeningPartCreate(ListeningPartBase):
    questions: List[ListeningQuestionCreate]
    # Part darajasidagi optionlar (Matching/Map uchun)
    options: Optional[List[OptionCreate]] = []

class ListeningPartResponse(ListeningPartBase):
    id: int
    questions: List[ListeningQuestionResponse]
    options: List[OptionResponse] = []

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

# ================================================================
#  EXAM (Imtihon)
# ================================================================
class ListeningExamBase(BaseModel):
    title: str
    isDemo: bool = Field(False, alias="is_demo")
    isFree: bool = Field(False, alias="is_free")
    isMock: bool = Field(False, alias="is_mock")
    isActive: bool = Field(True, alias="is_active")
    
    cefr_level: str = Field(..., alias="level") # Frontend "level" yuboradi, Modelda "cefr_level"
    duration_minutes: int = Field(35, alias="duration") # Frontend "duration", Modelda "duration_minutes"
    total_questions: int = Field(..., alias="totalQuestions")
    sections: str # "1,2,3,4"

    model_config = ConfigDict(populate_by_name=True)

class ListeningExamCreate(ListeningExamBase):
    id: str # Slug, masalan: listening-test-1
    parts: List[ListeningPartCreate]

class ListeningExamUpdate(BaseModel):
    """Imtihonni yangilash uchun sxema (Barcha maydonlar ixtiyoriy)"""
    title: Optional[str] = None
    isDemo: Optional[bool] = Field(None, alias="is_demo")
    isFree: Optional[bool] = Field(None, alias="is_free")
    isMock: Optional[bool] = Field(None, alias="is_mock")
    isActive: Optional[bool] = Field(None, alias="is_active")
    
    cefr_level: Optional[str] = Field(None, alias="level")
    duration_minutes: Optional[int] = Field(None, alias="duration")
    total_questions: Optional[int] = Field(None, alias="totalQuestions")
    sections: Optional[str] = None
    
    # Agar parts berilsa, eski qismlar o'chib, yangilari yoziladi
    parts: Optional[List[ListeningPartCreate]] = None

    model_config = ConfigDict(populate_by_name=True)

class ListeningExamResponse(ListeningExamBase):
    id: str
    parts: List[ListeningPartResponse]

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

# ================================================================
#  RESULTS & SUBMISSION (Natijalar)
# ================================================================
class ListeningSubmission(BaseModel):
    exam_id: str
    user_answers: Dict[str, str] = Field(..., description="Savol ID: Javob")

class ListeningResultResponse(BaseModel):
    id: int
    exam_id: str
    raw_score: int
    standard_score: float
    cefr_level: Optional[str]
    percentage: float
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class ListeningQuestionReview(BaseModel):
    """Imtihon tugagandan keyin ko'rsatiladigan tahlil"""
    question_number: int
    user_answer: Optional[str] = ""
    correct_answer: str # Bu yerda to'g'ri javobni ko'rsatish mumkin
    is_correct: bool
    type: ListeningQuestionType

    model_config = ConfigDict(from_attributes=True)

class ListeningResultDetailResponse(BaseModel):
    summary: ListeningResultResponse
    review: List[ListeningQuestionReview]

    model_config = ConfigDict(from_attributes=True)
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from sqlalchemy import delete, select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import HTTPException, status

# Modellar va Sxemalar
from .models import (
    ListeningExam, 
    ListeningPart, 
    ListeningQuestion, 
    ListeningQuestionOption, 
    ListeningPartOption,
    ListeningResult
)
from .schemas import ListeningExamCreate, ListeningExamUpdate, ListeningSubmission

# Logger
logger = logging.getLogger(__name__)

class ListeningService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ================================================================
    #  HELPER METHODS (Yordamchi funksiyalar)
    # ================================================================

    def _calculate_metrics(self, correct_answers: int) -> tuple[int, str]:
        """
        Multilevel (Agentlik) shkalasi bo'yicha Listening ballini hisoblash.
        Manba: Multilevel-bm.pdf [65]
        """
        # C1 Daraja: 28-35 ta to'g'ri javob -> 65-75 ball
        if 28 <= correct_answers <= 35:
            # Formula: 65 + (topgan - 28) * (oraliq_ball / oraliq_savol)
            score = 65 + (correct_answers - 28) * (75 - 65) // (35 - 28)
            return score, "C1"
        
        # B2 Daraja: 18-27 ta to'g'ri javob -> 51-64 ball
        elif 18 <= correct_answers <= 27:
            score = 51 + (correct_answers - 18) * (64 - 51) // (27 - 18)
            return score, "B2"
        
        # B1 Daraja: 10-17 ta to'g'ri javob -> 38-50 ball
        elif 10 <= correct_answers <= 17:
            score = 38 + (correct_answers - 10) * (50 - 38) // (17 - 10)
            return score, "B1"
        
        # B1 dan quyi: 0-9 ta to'g'ri javob -> 0-37 ball
        else:
            # 0 ballni handle qilish
            if correct_answers <= 0:
                return 0, "B1 dan quyi"
            score = (correct_answers * 37) // 9 
            return score, "B1 dan quyi"

    async def _create_parts_questions_options(self, exam_id: str, parts_data: List[Any]):
        """
        Part, Question va Optionlarni yaratish logikasi (Create va Update uchun umumiy).
        """
        for p_data in parts_data:
            # 1. Part (Bo'lim) yaratish
            new_part = ListeningPart(
                exam_id=exam_id,
                part_number=p_data.part_number,
                title=p_data.title,
                instruction=p_data.instruction,
                task_type=p_data.task_type,
                # Pydantic field name ishlatiladi (audio_url), alias (audioLabel) emas
                audio_url=p_data.audio_url, 
                context=p_data.context,
                passage=p_data.passage,
                map_image=p_data.map_image
            )
            self.db.add(new_part)
            await self.db.flush() # Part ID sini olish uchun

            # 2. Part darajasidagi Optionlarni saqlash (Matching/Map uchun)
            if p_data.options:
                for opt in p_data.options:
                    self.db.add(ListeningPartOption(
                        part_id=new_part.id,
                        value=opt.value,
                        label=opt.label
                    ))

            # 3. Savollarni (Questions) yaratish
            for q_data in p_data.questions:
                new_question = ListeningQuestion(
                    part_id=new_part.id,
                    question_number=q_data.question_number,
                    type=q_data.type,
                    # TUZATILDI: Schema da bu maydon 'text' deb nomlangan (alias='question')
                    text=q_data.text, 
                    correct_answer=q_data.correct_answer
                )
                self.db.add(new_question)
                await self.db.flush() # Question ID sini olish uchun

                # 4. Savol darajasidagi Optionlarni saqlash (Multiple Choice bo'lsa)
                if q_data.options:
                    for opt in q_data.options:
                        self.db.add(ListeningQuestionOption(
                            question_id=new_question.id,
                            value=opt.value,
                            label=opt.label
                        ))

    # ================================================================
    #  CRUD METHODS
    # ================================================================

    async def create_exam(self, data: ListeningExamCreate):
        try:
            # 1. Asosiy imtihonni (Exam) yaratish
            new_exam = ListeningExam(
                id=data.id,
                title=data.title,
                is_demo=data.isDemo,
                is_free=data.isFree,
                is_mock=data.isMock,
                is_active=data.isActive,
                sections=data.sections,
                cefr_level=data.cefr_level,
                duration_minutes=data.duration_minutes,
                total_questions=data.total_questions
            )
            self.db.add(new_exam)
            await self.db.flush() 
            
            # 2. Part va Savollarni yaratish (Yordamchi metod orqali)
            await self._create_parts_questions_options(new_exam.id, data.parts)

            # 3. Yakuniy saqlash
            await self.db.commit()
            return await self.get_exam_by_id(new_exam.id)

        except Exception as e:
            await self.db.rollback()
            logger.error(f"Create Listening Exam Error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Imtihonni yaratishda xatolik: {str(e)}"
            )
        
    async def get_all_exams(self):
        stmt = (
            select(ListeningExam)
            .options(selectinload(ListeningExam.parts))
            .order_by(ListeningExam.created_at.desc())
        )
        result = await self.db.execute(stmt)
        return result.unique().scalars().all()

    async def get_exam_by_id(self, exam_id: str):
        """Barcha detallari (savollar, variantlar) bilan imtihonni olish"""
        stmt = (
            select(ListeningExam)
            .where(ListeningExam.id == exam_id)
            .options(
                selectinload(ListeningExam.parts).options(
                    selectinload(ListeningPart.questions).selectinload(ListeningQuestion.options),
                    selectinload(ListeningPart.options)
                )
            )
        )
        result = await self.db.execute(stmt)
        exam = result.unique().scalar_one_or_none()
        if not exam:
            return None 
        return exam

    async def update_exam(self, exam_id: str, data: ListeningExamUpdate):
        # 1. Avval mavjud imtihonni qidiramiz
        exam = await self.get_exam_by_id(exam_id)
        if not exam:
            raise HTTPException(status_code=404, detail="Yangilash uchun imtihon topilmadi")

        try:
            # 2. Asosiy ma'lumotlarni yangilash
            update_data = data.dict(exclude_unset=True)
            
            if 'title' in update_data: exam.title = update_data['title']
            if 'isDemo' in update_data: exam.is_demo = update_data['isDemo']
            if 'isFree' in update_data: exam.is_free = update_data['isFree']
            if 'isMock' in update_data: exam.is_mock = update_data['isMock']
            if 'isActive' in update_data: exam.is_active = update_data['isActive']
            if 'sections' in update_data: exam.sections = update_data['sections']
            if 'cefr_level' in update_data: exam.cefr_level = update_data['cefr_level']
            if 'duration_minutes' in update_data: exam.duration_minutes = update_data['duration_minutes']
            if 'total_questions' in update_data: exam.total_questions = update_data['total_questions']

            # 3. Agar 'parts' yangilanayotgan bo'lsa (To'liq almashtirish)
            if data.parts is not None:
                # Eski ma'lumotlarni tozalash
                await self.db.execute(delete(ListeningPart).where(ListeningPart.exam_id == exam_id))
                await self.db.flush()

                # Yangilarini yaratish
                await self._create_parts_questions_options(exam.id, data.parts)

            await self.db.commit()
            return await self.get_exam_by_id(exam.id)

        except Exception as e:
            await self.db.rollback()
            logger.error(f"Update Listening Exam Error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Yangilashda xatolik yuz berdi: {str(e)}"
            )
            
    async def delete_exam(self, exam_id: str):
        stmt = select(ListeningExam).where(ListeningExam.id == exam_id)
        result = await self.db.execute(stmt)
        exam = result.scalar_one_or_none()

        if not exam:
            return False

        try:
            await self.db.delete(exam)
            await self.db.commit()
            return True
        except Exception as e:
            await self.db.rollback()
            raise HTTPException(status_code=400, detail=f"O'chirishda xatolik: {str(e)}")

    # ================================================================
    #  RESULT & SUBMISSION METHODS
    # ================================================================

    async def submit_exam_and_get_result(self, user_id: int, data: ListeningSubmission):
        # 1. Imtihonni olish
        exam = await self.get_exam_by_id(data.exam_id)
        if not exam:
            raise HTTPException(status_code=404, detail="Exam topilmadi")
        
        correct_count = 0
        total_q = 0
        review_items = []
        
        # 2. Tekshirish logikasi
        for part in exam.parts:
            for q in part.questions:
                total_q += 1
                q_id_str = str(q.id)
                
                # User javobi
                u_ans = data.user_answers.get(q_id_str, "").strip().lower()
                
                # To'g'ri javob (Slash bilan bo'lingan variantlarni hisobga olish)
                c_ans_raw = q.correct_answer.strip().lower()
                valid_options = [a.strip() for a in c_ans_raw.split("/")]
                
                is_correct = u_ans in valid_options
                
                if is_correct:
                    correct_count += 1
                
                review_items.append({
                    "question_number": q.question_number,
                    "user_answer": data.user_answers.get(q_id_str, ""), # Asl format
                    "correct_answer": q.correct_answer,
                    "is_correct": is_correct,
                    "type": q.type
                })

        # 3. Hisoblashlar (Agentlik shkalasi bo'yicha)
        std_score, cefr_level = self._calculate_metrics(correct_count)
        
        # Foiz hisoblash
        percentage = (correct_count / total_q) * 100 if total_q > 0 else 0.0

        # 4. Bazaga saqlash
        new_result = ListeningResult(
            user_id=user_id,
            exam_id=exam.id,
            total_questions=total_q,
            correct_answers=correct_count,
            raw_score=correct_count,
            standard_score=float(std_score),
            percentage=float(percentage),
            cefr_level=cefr_level,
            user_answers=data.user_answers # JSON formatda
        )
        
        try:
            self.db.add(new_result)
            await self.db.commit()
            await self.db.refresh(new_result)
        except Exception as e:
            await self.db.rollback()
            raise HTTPException(status_code=400, detail=f"Natijani saqlashda xatolik: {str(e)}")
        
        return {
            "summary": new_result,
            "review": review_items
        }

    async def get_user_results(self, user_id: int):
        stmt = (
            select(ListeningResult)
            .where(ListeningResult.user_id == user_id)
            .order_by(ListeningResult.created_at.desc())
        )
        result = await self.db.execute(stmt)
        return result.scalars().all()

    async def get_result_with_review(self, result_id: int, user_id: int):
        """Review (Tahlil) sahifasi uchun ma'lumotlar"""
        stmt = select(ListeningResult).where(
            ListeningResult.id == result_id, 
            ListeningResult.user_id == user_id
        )
        res = await self.db.execute(stmt)
        result_data = res.scalar_one_or_none()
        
        if not result_data:
            return None 

        # Imtihon savollarini yuklab olamiz
        exam = await self.get_exam_by_id(result_data.exam_id)
        if not exam:
            return None
        
        review_data = []
        for part in exam.parts:
            for q in part.questions:
                u_ans = result_data.user_answers.get(str(q.id), "").strip().lower()
                
                c_ans_raw = q.correct_answer.strip().lower()
                valid_options = [a.strip() for a in c_ans_raw.split("/")]
                
                is_correct = u_ans in valid_options
                
                review_data.append({
                    "question_number": q.question_number,
                    "user_answer": result_data.user_answers.get(str(q.id), ""), # Asl ko'rinish
                    "correct_answer": q.correct_answer,
                    "is_correct": is_correct,
                    "type": q.type
                })
                
        return {
            "summary": result_data,
            "review": review_data
        }
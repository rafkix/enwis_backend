import enum
from sqlalchemy import (
    JSON, Column, DateTime, Float, Integer, String, Text, Enum, ForeignKey, Boolean, func
)
from sqlalchemy.orm import relationship
from app.core.database import Base # Base sizning loyihangizda qayerda bo'lsa o'sha yerdan oling

# --- ENUMS ---
class QuestionType(str, enum.Enum):
    MULTIPLE_CHOICE = "MULTIPLE_CHOICE"
    TRUE_FALSE_NOT_GIVEN = "TRUE_FALSE_NOT_GIVEN"
    GAP_FILL = "GAP_FILL"
    GAP_FILL_FILL = "GAP_FILL_FILL"
    HEADINGS_MATCH = "HEADINGS_MATCH"
    MULTIPLE_SELECT = "MULTIPLE_SELECT"
    TEXT_MATCH = "TEXT_MATCH"

# --- EXAM (READING) ---
class Exam(Base):
    __tablename__ = "reading_exams"

    # ID string bo'lgani yaxshi (masalan: "ielts-reading-test-1")
    id = Column(String, primary_key=True, index=True) 
    title = Column(String, nullable=False)
    
    # Statuslar
    is_demo = Column(Boolean, default=False)
    is_free = Column(Boolean, default=False)
    is_mock = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    
    # Ma'lumotlar
    cefr_level = Column(String, nullable=False, default="B2")
    duration_minutes = Column(Integer, nullable=False, default=60)
    language = Column(String, default="en")
    type = Column(String, default="READING") # "READING", "LISTENING"
    total_questions = Column(Integer, default=40)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Bog'lanishlar
    # cascade="all, delete-orphan" -> Exam o'chirilganda uning qismlari va natijalari ham o'chadi
    parts = relationship("ReadingPart", back_populates="exam", cascade="all, delete-orphan", lazy="selectin")
    results = relationship("ReadingResult", back_populates="exam", cascade="all, delete-orphan")

# --- READING PARTS (Passages) ---
class ReadingPart(Base):
    __tablename__ = "reading_parts"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(String, ForeignKey("reading_exams.id", ondelete="CASCADE"), nullable=False)
    
    title = Column(String, nullable=False) # Passage 1, Passage 2...
    description = Column(Text, nullable=True)
    passage = Column(Text, nullable=False) # Asosiy matn

    exam = relationship("Exam", back_populates="parts")
    questions = relationship("Question", back_populates="part", cascade="all, delete-orphan", lazy="selectin")

# --- QUESTIONS ---
class Question(Base):
    __tablename__ = "reading_questions"

    id = Column(Integer, primary_key=True, index=True)
    part_id = Column(Integer, ForeignKey("reading_parts.id", ondelete="CASCADE"), nullable=False)
    
    question_number = Column(Integer, nullable=False)
    
    # native_enum=False -> Bazada VARCHAR sifatida saqlaydi (Migratsiya uchun xavfsiz)
    type = Column(Enum(QuestionType, native_enum=False), nullable=False)
    
    text = Column(Text, nullable=False) # Savol matni
    correct_answer = Column(String, nullable=False) # To'g'ri javob
    word_limit = Column(Integer, nullable=True) # Gap fill uchun (masalan: 2 so'z)

    part = relationship("ReadingPart", back_populates="questions")
    options = relationship("QuestionOption", back_populates="question", cascade="all, delete-orphan", lazy="selectin")

# --- OPTIONS (Multiple Choice uchun) ---
class QuestionOption(Base):
    __tablename__ = "reading_question_options"

    id = Column(Integer, primary_key=True, index=True)
    question_id = Column(Integer, ForeignKey("reading_questions.id", ondelete="CASCADE"), nullable=False)
    
    label = Column(String, nullable=False) # A, B, C, D
    value = Column(String, nullable=False) # Variant matni

    question = relationship("Question", back_populates="options")

# --- RESULTS ---
class ReadingResult(Base):
    __tablename__ = "reading_exam_results"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    exam_id = Column(String, ForeignKey("reading_exams.id", ondelete="CASCADE"), nullable=False)
    
    # Natijalar (boshida null bo'lishi mumkin, hisoblangach yoziladi)
    raw_score = Column(Integer, default=0)
    standard_score = Column(Float, default=0.0)
    cefr_level = Column(String, nullable=True)
    percentage = Column(Float, default=0.0)
    
    # User javoblari: {"1": "answer", "2": "answer"}
    user_answers = Column(JSON, nullable=False, default={})
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # User modeli bu faylda bo'lmasa ham, string ('User') orqali bog'lash mumkin.
    # DIQQAT: User modelida 'reading_results = relationship(...)' bo'lishi kerak.
    user = relationship("User", back_populates="reading_results")
    exam = relationship("Exam", back_populates="results")
from typing import List, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

# Database va Auth dependency
from app.core.database import get_db
from app.modules.auth.dependencies import get_current_user

# Lokal importlar (Schema va Service)
from .schemas import (
    ExamCreate, 
    ExamUpdate, 
    ExamResponse, 
    ResultSubmission, 
    ResultResponse,
    ReadingResultDetailResponse
)
from .services import ReadingExamService

# Router sozlamalari
router = APIRouter(
    prefix="/services/cefr/reading",
    tags=["CEFR Reading"]
)

# =================================================================
#  1. IMTIHON BOSHQARUVI (ADMIN/MODERATOR)
#  Eslatma: Bu yerga Admin ekanligini tekshiruvchi dependency qo'shish tavsiya etiladi.
# =================================================================

@router.post("/create", response_model=ExamResponse, status_code=status.HTTP_201_CREATED)
async def create_exam(
    payload: ExamCreate,
    db: AsyncSession = Depends(get_db)
):
    """
    Yangi Reading imtihoni yaratish.
    """
    service = ReadingExamService(db)
    
    # ID band ekanligini tekshirish
    if await service.get_exam(payload.id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Bu ID bilan imtihon allaqachon mavjud"
        )
    
    return await service.create_exam(payload)


@router.get("/list", response_model=List[ExamResponse])
async def list_exams(db: AsyncSession = Depends(get_db)):
    """
    Barcha mavjud imtihonlar ro'yxatini olish.
    """
    service = ReadingExamService(db)
    return await service.get_all_exams()


@router.get("/{exam_id}", response_model=ExamResponse)
async def get_exam(exam_id: str, db: AsyncSession = Depends(get_db)):
    """
    Muayyan imtihonni barcha qismlari va savollari bilan olish.
    """
    service = ReadingExamService(db)
    exam = await service.get_exam(exam_id)
    
    if not exam:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Imtihon topilmadi")
    
    return exam


@router.put("/update/{exam_id}", response_model=ExamResponse)
async def update_exam(
    exam_id: str,
    data: ExamUpdate,
    db: AsyncSession = Depends(get_db)
):
    """
    Imtihon ma'lumotlarini yangilash (Title, Timer, Savollar...).
    """
    service = ReadingExamService(db)
    # Service ichida 404 tekshiruvi bor, shuning uchun try/catch shart emas (agar service raise qilsa)
    # Lekin xavfsizlik uchun bu yerda ham tekshirish mumkin.
    updated_exam = await service.update_exam(exam_id, data)
    return updated_exam


@router.delete("/delete/{exam_id}")
async def delete_exam(exam_id: str, db: AsyncSession = Depends(get_db)):
    """
    Imtihonni o'chirish.
    """
    service = ReadingExamService(db)
    success = await service.delete_exam(exam_id)
    
    if not success:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Imtihon topilmadi")
    
    return {"success": True, "message": "Imtihon muvaffaqiyatli o'chirildi"}


# =================================================================
#  2. NATIJALAR VA TOPSHIRISH (USER)
# =================================================================

@router.post("/submit", response_model=ReadingResultDetailResponse)
async def submit_exam(
    payload: ResultSubmission,
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user) # User model turini yozishingiz mumkin
):
    """
    Imtihon javoblarini topshirish va natijani hisoblash.
    """
    service = ReadingExamService(db)
    return await service.submit_exam_and_get_result(user.id, payload)


@router.get("/results/my", response_model=List[ResultResponse])
async def get_my_results(
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user)
):
    """
    Foydalanuvchining barcha topshirgan imtihonlari natijalari.
    """
    service = ReadingExamService(db)
    return await service.get_user_results(user.id)


@router.get("/results/{result_id}", response_model=ReadingResultDetailResponse)
async def get_result_detail(
    result_id: int,
    db: AsyncSession = Depends(get_db),
    user: Any = Depends(get_current_user)
):
    """
    Muayyan natijani tahlili (review) bilan birga ko'rish.
    (Bu funksiyani Servisga qo'shgan edik: get_result_with_review)
    """
    service = ReadingExamService(db)
    result = await service.get_result_with_review(result_id, user.id)
    
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Natija topilmadi yoki sizga tegishli emas")
    
    return result
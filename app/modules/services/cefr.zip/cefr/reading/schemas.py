from pydantic import BaseModel, Field, ConfigDict
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime

# ================================================================
#  ENUMS
# ================================================================
class QuestionType(str, Enum):
    MULTIPLE_CHOICE = "MULTIPLE_CHOICE"
    TRUE_FALSE_NOT_GIVEN = "TRUE_FALSE_NOT_GIVEN"
    GAP_FILL = "GAP_FILL"
    GAP_FILL_FILL = "GAP_FILL_FILL"
    HEADINGS_MATCH = "HEADINGS_MATCH"
    MULTIPLE_SELECT = "MULTIPLE_SELECT"
    TEXT_MATCH = "TEXT_MATCH"

# ================================================================
#  OPTIONS (Variantlar)
# ================================================================
class OptionBase(BaseModel):
    label: str  # A, B, C...
    value: str  # Variant matni

class OptionCreate(OptionBase):
    pass

class OptionResponse(OptionBase):
    id: int # ID qaytarish foydali bo'lishi mumkin
    model_config = ConfigDict(from_attributes=True)

# ================================================================
#  QUESTIONS (Savollar)
# ================================================================
class QuestionBase(BaseModel):
    question_number: Optional[int] = Field(None, alias="question_number")
    type: QuestionType
    text: str
    word_limit: Optional[int] = Field(None, alias="word_limit")
    
    model_config = ConfigDict(populate_by_name=True)

class QuestionCreate(QuestionBase):
    correct_answer: str = Field(..., alias="correct_answer") # Yaratishda kerak
    options: Optional[List[OptionCreate]] = []

class QuestionResponse(QuestionBase):
    id: int
    options: List[OptionResponse] = []
    
    # DIQQAT: correct_answer bu yerda yo'q! 
    # Imtihon paytida javobni frontendga yubormaslik kerak.

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

# ================================================================
#  PARTS (Passages)
# ================================================================
class PartBase(BaseModel):
    title: str
    description: str
    passage: str

class ReadingPartCreate(PartBase):
    questions: List[QuestionCreate]

class ReadingPartResponse(PartBase):
    id: int
    questions: List[QuestionResponse]

    model_config = ConfigDict(from_attributes=True)

# ================================================================
#  EXAM (Imtihon)
# ================================================================
class ExamBase(BaseModel):
    title: str
    isDemo: bool = Field(False, alias="is_demo")
    isFree: bool = Field(False, alias="is_free")
    isMock: bool = Field(False, alias="is_mock")
    isActive: bool = Field(True, alias="is_active")
    cefr_level: str = Field(..., alias="cefr_level")
    duration_minutes: int = Field(60, alias="duration_minutes")
    language: str = "en"
    total_questions: int = Field(35, alias="total_questions")
    type: str = Field("READING", description="READING yoki LISTENING")

    model_config = ConfigDict(populate_by_name=True)

class ExamCreate(ExamBase):
    id: str  # Slug, masalan: reading-test-1
    parts: List[ReadingPartCreate]

class ExamUpdate(BaseModel):
    title: Optional[str] = None
    isDemo: Optional[bool] = Field(None, alias="is_demo")
    isFree: Optional[bool] = Field(None, alias="is_free")
    isMock: Optional[bool] = Field(None, alias="is_mock")
    isActive: Optional[bool] = Field(None, alias="is_active")
    cefr_level: Optional[str] = Field(None, alias="cefr_level")
    duration_minutes: Optional[int] = Field(None, alias="duration_minutes")
    total_questions: Optional[int] = Field(None, alias="total_questions")
    parts: Optional[List[ReadingPartCreate]] = None

    model_config = ConfigDict(populate_by_name=True)

class ExamResponse(ExamBase):
    id: str
    parts: List[ReadingPartResponse]

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

# ================================================================
#  RESULTS & SUBMISSION
# ================================================================
class ResultSubmission(BaseModel):
    exam_id: str
    user_answers: Dict[str, str] = Field(..., description="Savol ID: Javob")

class ResultResponse(BaseModel):
    id: int
    exam_id: str
    raw_score: int
    standard_score: float
    cefr_level: str
    percentage: float
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class QuestionReview(BaseModel):
    question_number: int
    user_answer: Optional[str] = ""
    correct_answer: str # Review paytida to'g'ri javobni ko'rsatamiz
    is_correct: bool
    type: QuestionType

    model_config = ConfigDict(from_attributes=True)

class ReadingResultDetailResponse(BaseModel):
    summary: ResultResponse
    review: List[QuestionReview]

    model_config = ConfigDict(from_attributes=True)
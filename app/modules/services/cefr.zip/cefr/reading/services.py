import logging
from typing import List, Optional, Dict, Any

from sqlalchemy import delete, select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import HTTPException, status

# Modellar va Sxemalar importi (Yo'llarni loyihangizga qarab to'g'rilang)
from .models import (
    Exam, 
    ReadingPart, 
    Question, 
    QuestionOption, 
    ReadingResult
)
from .schemas import ExamCreate, ResultSubmission, ExamUpdate

# Logger
logger = logging.getLogger(__name__)

class ReadingExamService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ================================================================
    #  HELPER METHODS (Yordamchi funksiyalar)
    # ================================================================
    
    def _build_exam_parts(self, parts_data: List[Any]) -> List[ReadingPart]:
        """
        Pydantic sxemasidagi 'parts' ro'yxatidan SQLAlchemy modellarini yasab beradi.
        Create va Update metodlarida kodni qayta yozmaslik uchun ishlatiladi.
        """
        reading_parts = []
        
        for p_data in parts_data:
            # 1. Part yaratish
            part = ReadingPart(
                title=p_data.title,
                description=p_data.description,
                passage=p_data.passage,
                questions=[]  # Relationshipni shu yerda initsializatsiya qilamiz
            )
            
            # 2. Savollarni yaratish
            for q_idx, q_data in enumerate(p_data.questions):
                question = Question(
                    question_number=q_data.question_number or (q_idx + 1),
                    # Enum qiymatini string sifatida olish kerak bo'lishi mumkin (agar native_enum=False bo'lsa)
                    # Lekin SQLAlchemy o'zi handle qiladi, agar type Pydantic Enum bo'lsa.
                    type=q_data.type, 
                    text=q_data.text,
                    correct_answer=q_data.correct_answer,
                    word_limit=q_data.word_limit,
                    options=[]
                )
                
                # 3. Variantlarni yaratish (faqat Multiple Choice uchun)
                if q_data.options:
                    for opt in q_data.options:
                        question.options.append(
                            QuestionOption(label=opt.label, value=opt.value)
                        )
                
                part.questions.append(question)
            reading_parts.append(part)
            
        return reading_parts

    def _calculate_metrics(self, correct: int, total: int):
        """
        Natija va CEFR darajasini hisoblash (Reading shkalasi bo'yicha).
        """
        if total == 0:
            return 0.0, "N/A"

        # Reading uchun taxminiy shkala (IELTS/CEFR standarti asosida moslash mumkin)
        # Bu mantiqni o'zingizning aniq talablaringizga qarab o'zgartirishingiz mumkin.
        if correct >= 28:
            # C1 darajasi (yuqori ball)
            score = round(65 + (correct - 28) * 1.42, 1)
            return min(score, 75.0), "C1"
        elif correct >= 18:
            # B2 darajasi (o'rta yuqori)
            score = round(51 + (correct - 18) * 1.4, 1)
            return score, "B2"
        elif correct >= 10:
            # B1 darajasi (o'rta)
            score = round(38 + (correct - 10) * 1.62, 1)
            return score, "B1"
        else:
            # B1 dan past
            return round(correct * 3.7, 1), "B1 dan past"

    # ================================================================
    #  CRUD METHODS (Create, Read, Update, Delete)
    # ================================================================

    async def create_exam(self, payload: ExamCreate) -> Exam:
        """
        Yangi imtihon yaratish.
        """
        try:
            # 1. Asosiy Exam ob'ektini yaratish
            exam = Exam(
                id=payload.id,
                title=payload.title,
                is_demo=payload.isDemo,
                is_free=payload.isFree,
                is_mock=payload.isMock,
                is_active=payload.isActive,
                cefr_level=payload.cefr_level,
                duration_minutes=payload.duration_minutes,
                language=payload.language,
                type=payload.type,
                total_questions=payload.total_questions
            )

            # 2. Qismlar, savollar va variantlarni yordamchi metod orqali qo'shish
            exam.parts = self._build_exam_parts(payload.parts)

            self.db.add(exam)
            await self.db.commit()
            
            # Yaratilgandan so'ng to'liq ma'lumotni qaytarish (relationship'lar bilan)
            return await self.get_exam(exam.id)

        except Exception as e:
            await self.db.rollback()
            logger.error(f"Create Exam Error: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, 
                detail=f"Imtihonni saqlashda xatolik: {str(e)}"
            )

    async def get_exam(self, exam_id: str) -> Optional[Exam]:
        """
        Imtihonni barcha bog'liqliklari (Parts -> Questions -> Options) bilan olish.
        """
        stmt = (
            select(Exam)
            .where(Exam.id == exam_id)
            .options(
                selectinload(Exam.parts)
                .selectinload(ReadingPart.questions)
                .selectinload(Question.options)
            )
        )
        result = await self.db.execute(stmt)
        return result.unique().scalar_one_or_none()

    async def get_all_exams(self) -> List[Exam]:
        """
        Barcha imtihonlarni ro'yxatini olish.
        """
        # Ro'yxatda faqat asosiy ma'lumotlar kerak bo'lsa, 'parts'ni yuklamaslik ham mumkin
        # Lekin UI da partlar sonini ko'rsatish kerak bo'lsa yuklagan ma'qul.
        stmt = select(Exam).options(selectinload(Exam.parts))
        result = await self.db.execute(stmt)
        return result.unique().scalars().all()

    async def update_exam(self, exam_id: str, data: ExamUpdate) -> Exam:
        """
        Imtihonni yangilash. 
        Diqqat: Parts yangilanganda eskilar o'chib ketadi va yangilari yoziladi (Full Replace).
        """
        exam = await self.get_exam(exam_id)
        if not exam:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Exam topilmadi")

        try:
            # 1. Asosiy maydonlarni yangilash
            update_data = data.dict(exclude_unset=True)
            
            # Sxemadagi nomlar (alias) va Modeldagi nomlar bir xil bo'lmagan holatlarni qo'lda map qilish kerak
            # Agar 'populate_by_name=True' ishlatilsa, Pydantic model nomlarini qaytaradi, shuning uchun to'g'ri tushadi.
            
            if 'title' in update_data: exam.title = update_data['title']
            if 'cefr_level' in update_data: exam.cefr_level = update_data['cefr_level']
            if 'duration_minutes' in update_data: exam.duration_minutes = update_data['duration_minutes']
            if 'total_questions' in update_data: exam.total_questions = update_data['total_questions']
            if 'isMock' in update_data: exam.is_mock = update_data['isMock']
            if 'isActive' in update_data: exam.is_active = update_data['isActive']
            if 'isDemo' in update_data: exam.is_demo = update_data['isDemo']
            if 'isFree' in update_data: exam.is_free = update_data['isFree']
            
            # 2. Qismlarni yangilash (Eskisini o'chirish -> Yangisini yozish)
            if data.parts is not None:
                # Eski qismlarni o'chirish (Cascade tufayli savollar ham o'chadi)
                await self.db.execute(delete(ReadingPart).where(ReadingPart.exam_id == exam_id))
                await self.db.flush() # O'chirishni bazaga zudlik bilan bildirish

                # Yangi qismlarni qo'shish
                new_parts = self._build_exam_parts(data.parts)
                for part in new_parts:
                    part.exam_id = exam.id # ID bog'lash
                    # 'exam.parts.append(part)' o'rniga to'g'ridan-to'g'ri sessiyaga qo'shish xavfsizroq
                    # lekin relationship orqali ishlash ham to'g'ri.
                    exam.parts.append(part)

            await self.db.commit()
            return await self.get_exam(exam.id)

        except Exception as e:
            await self.db.rollback()
            logger.error(f"Update Exam Error: {str(e)}")
            raise HTTPException(status_code=400, detail=f"Update xatoligi: {str(e)}")

    async def delete_exam(self, exam_id: str) -> bool:
        """
        Imtihonni o'chirish.
        """
        exam = await self.get_exam(exam_id)
        if not exam:
            return False
        
        try:
            await self.db.delete(exam)
            await self.db.commit()
            return True
        except Exception as e:
            await self.db.rollback()
            raise HTTPException(status_code=400, detail=f"O'chirishda xatolik: {str(e)}")

    # ================================================================
    #  RESULT & SUBMISSION METHODS (Natijalar)
    # ================================================================

    async def submit_exam_and_get_result(self, user_id: int, data: ResultSubmission) -> Dict[str, Any]:
        """
        Foydalanuvchi javoblarini qabul qilish, tekshirish va natijani saqlash.
        """
        exam = await self.get_exam(data.exam_id)
        if not exam:
            raise HTTPException(status_code=404, detail="Exam topilmadi")

        correct_count = 0
        total_q = 0
        review_items = []

        # Javoblarni tekshirish
        for part in exam.parts:
            for q in part.questions:
                total_q += 1
                q_id_str = str(q.id)
                
                # User javobi va to'g'ri javobni normalizatsiya qilish (bo'sh joylarni olish, kichik harfga o'tkazish)
                user_ans = data.user_answers.get(q_id_str, "").strip().lower()
                correct_ans_raw = q.correct_answer.strip().lower()
                
                # Ko'p variantli javoblar (masalan: "car/a car" yoki "True/Yes")
                valid_options = [a.strip() for a in correct_ans_raw.split("/")]
                
                is_correct = user_ans in valid_options
                if is_correct:
                    correct_count += 1
                
                review_items.append({
                    "question_number": q.question_number,
                    "user_answer": user_ans,
                    "correct_answer": q.correct_answer,
                    "is_correct": is_correct,
                    "type": q.type
                })

        # Ball hisoblash
        std_score, level = self._calculate_metrics(correct_count, total_q)
        
        # Foizni hisoblash
        percentage = (correct_count / total_q) * 100 if total_q > 0 else 0

        # Natijani bazaga yozish
        new_result = ReadingResult(
            user_id=user_id,
            exam_id=exam.id,
            raw_score=correct_count,
            standard_score=float(std_score),
            cefr_level=level,
            percentage=percentage,
            user_answers=data.user_answers
        )
        
        try:
            self.db.add(new_result)
            await self.db.commit()
            await self.db.refresh(new_result)
        except Exception as e:
            await self.db.rollback()
            raise HTTPException(status_code=400, detail=f"Natijani saqlashda xatolik: {str(e)}")
        
        return {
            "summary": new_result,
            "review": review_items
        }

    async def get_result_with_review(self, result_id: int, user_id: int) -> Optional[Dict[str, Any]]:
        """
        Saqlangan natijani va batafsil tahlilni (review) qaytaradi.
        """
        # 1. Natijani olish
        stmt = select(ReadingResult).where(
            ReadingResult.id == result_id, 
            ReadingResult.user_id == user_id
        )
        res = await self.db.execute(stmt)
        result_obj = res.scalar_one_or_none()
        
        if not result_obj:
            return None

        # 2. Imtihon ma'lumotlarini olish (to'g'ri javoblarni solishtirish uchun)
        exam = await self.get_exam(result_obj.exam_id)
        if not exam:
            return None

        review_data = []
        
        # 3. Tahlilni qayta shakllantirish
        for part in exam.parts:
            for q in part.questions:
                # User javobini olish
                u_ans = result_obj.user_answers.get(str(q.id), "").strip().lower()
                
                # To'g'ri javobni olish va tekshirish
                correct_ans_raw = q.correct_answer.strip().lower()
                valid_options = [a.strip() for a in correct_ans_raw.split("/")]
                
                is_correct = u_ans in valid_options
                
                review_data.append({
                    "question_number": q.question_number,
                    "user_answer": result_obj.user_answers.get(str(q.id), ""), # Asl formatda (katta-kichik harf o'zgarmagan) qaytarish
                    "correct_answer": q.correct_answer,
                    "is_correct": is_correct,
                    "type": q.type
                })
        
        return {
            "summary": result_obj,
            "review": review_data
        }

    async def get_user_results(self, user_id: int) -> List[ReadingResult]:
        """
        Foydalanuvchining barcha natijalarini olish.
        """
        stmt = (
            select(ReadingResult)
            .where(ReadingResult.user_id == user_id)
            .order_by(ReadingResult.created_at.desc())
        )
        res = await self.db.execute(stmt)
        return res.scalars().all()